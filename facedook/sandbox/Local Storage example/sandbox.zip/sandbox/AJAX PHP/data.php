<html>
	<body>
		<?php

    //read
    $myfile = fopen("data.txt", "r") or die("Unable to open file!");
    echo fread($myfile,filesize("data.txt"));
    fclose($myfile);

    //write
    $myfile = fopen("data.txt", "w") or die("Unable to open file!");
    $txt = "sike there's new data in here\n";
    fwrite($myfile, $txt);
    fclose($myfile);

    ?>
	</body>
</html>
